
// Get the canvas element
const canvas = document.querySelector("#c");
const renderer = new THREE.WebGLRenderer({ canvas });

// Set up the scene, camera, and lights
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(
  75,
  window.innerWidth / window.innerHeight,
  0.1,
  1000
);
camera.position.z = 5;

const ambientLight = new THREE.AmbientLight(0x404040); // Soft white light
scene.add(ambientLight);

const directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);
directionalLight.position.set(0, 1, 1);
scene.add(directionalLight);

// Create a basic cylinder geometry for the can
const canGeometry = new THREE.CylinderGeometry(1, 1, 3, 32);
const canMaterial = new THREE.MeshPhongMaterial({ color: 0xff0000 }); // Red color for Coca-Cola initially
const can = new THREE.Mesh(canGeometry, canMaterial);
scene.add(can);

// Function to update can color
function updateCanColor(color) {
  can.material.color.set(color);
}

// Event listeners for the buttons
document
  .getElementById("cocaButton")
  .addEventListener("click", () => updateCanColor(0xff0000)); // Red
document
  .getElementById("fantaButton")
  .addEventListener("click", () => updateCanColor(0xffa500)); // Orange
document
  .getElementById("spriteButton")
  .addEventListener("click", () => updateCanColor(0x00ff00)); // Green
document
  .getElementById("wireframeButton")
  .addEventListener("click", () => {
    can.material.wireframe = !can.material.wireframe;
  });
document.getElementById("lightButton").addEventListener("click", () => {
  directionalLight.visible = !directionalLight.visible;
});

// Animation loop
function animate() {
  requestAnimationFrame(animate);

  can.rotation.x += 0.01;
  can.rotation.y += 0.01;
  can.rotation.z += 0.01;

  renderer.render(scene, camera);
}

animate();