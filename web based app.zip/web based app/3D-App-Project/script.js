let scene, camera, renderer, model = null, light;

// Initialize the scene
function init() {
  // Scene
  scene = new THREE.Scene();

  // Camera
  camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
  camera.position.z = 5;

  // Renderer
  renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(window.innerWidth * 0.8, 500);
  document.getElementById('model-container').appendChild(renderer.domElement);

  // Lighting
  light = new THREE.DirectionalLight(0xffffff, 1);
  light.position.set(5, 5, 5).normalize();
  scene.add(light);

  // Load initial model (Coca)
  loadModel('models/coca.glb', 'textures/coca_texture.jpg');

  // Animation loop
  animate();
}

// Load a 3D model and apply texture
function loadModel(modelUrl, textureUrl) {
  if (model) scene.remove(model); // Remove previous model

  const loader = new THREE.GLTFLoader();
  const textureLoader = new THREE.TextureLoader();

  // Load texture
  const texture = textureLoader.load(
    textureUrl,
    function (texture) {
      texture.flipY = false; // Adjust if the texture appears flipped

      // Load model
      loader.load(
        modelUrl,
        function (gltf) {
          model = gltf.scene;

          // Apply texture to all materials in the model
          model.traverse((child) => {
            if (child.isMesh) {
              child.material.map = texture;
              child.material.needsUpdate = true;
            }
          });

          scene.add(model);
        },
        undefined, // Progress callback (optional)
        function (error) {
          console.error('Error loading model:', error);
        }
      );
    },
    undefined, // Progress callback (optional)
    function (error) {
      console.error('Error loading texture:', error);
    }
  );
}

// Toggle wireframe mode
function toggleWireframe() {
  if (!model) {
    console.error('No model loaded.');
    return;
  }
  model.traverse((child) => {
    if (child.isMesh) {
      child.material.wireframe = !child.material.wireframe;
    }
  });
}

// Toggle lighting
function toggleLight() {
  light.visible = !light.visible;
}

// Animation loop
function animate() {
  requestAnimationFrame(animate);
  if (model) model.rotation.y += 0.01; // Rotate the model
  renderer.render(scene, camera);
}

// Initialize the app
init();