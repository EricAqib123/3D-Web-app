# 3D Soda App

This is a 3D web application that showcases soda models (Coca, Fanta, and Sprite) using **Three.js** and **Blender**. Users can interact with the models by rotating, toggling wireframe mode, and controlling lighting.

![Screenshot of the 3D Soda App](screenshot.png) <!-- Add a screenshot if available -->

## Features
- Load and View 3D Models: Display 3D models of Coca, Fanta, and Sprite.
- Toggle Wireframe Mode: Switch between solid and wireframe views of the models.
- Control Lighting: Turn the light on or off to enhance the visual experience.
- Responsive Design: Works on desktop, tablet, and mobile devices.
- Interactive Gallery: Click on thumbnails to load different models.

## Technologies Used
- Three.js: A JavaScript library for 3D rendering.
- Blender: Used to create and export 3D models.
- HTML5, CSS3, JavaScript: For the web interface and interactivity.

## How to Run the App
1. unzip "3D-App-Project.zip" folder
2. Navigate to the Project Folder:
cd 3D-App-Project
3. Serve the Project Using a Local Web Server:
python -m http.server 8000
4. Open Your Browser:
http://localhost:8000




Folder Structure
3D-App-Project/
│
├── models/              # Contains 3D model files (.glb)
│   ├── coca.glb
│   ├── fanta.glb
│   └── sprite.glb
│
├── textures/            # Contains texture files (.jpg)
│   ├── coca_texture.jpg
│   ├── fanta_texture.jpg
│   └── sprite_texture.jpg
│
├── index.html           # Main HTML file
├── styles.css           # CSS file for styling
├── script.js            # JavaScript file for interactivity
├── about.html           # About page
├── README.md            # Project documentation


