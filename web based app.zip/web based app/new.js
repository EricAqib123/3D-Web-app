// Initialize Three.js scene
const canvas = document.querySelector("#c");
const renderer = new THREE.WebGLRenderer({ 
  canvas,
  antialias: true 
});
renderer.setClearColor(0xf0f0f0);

// Scene setup
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(
  75,
  canvas.clientWidth / canvas.clientHeight,
  0.1,
  1000
);
camera.position.z = 5;

// Lighting
const ambientLight = new THREE.AmbientLight(0x404040);
scene.add(ambientLight);

const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
directionalLight.position.set(0, 1, 1);
scene.add(directionalLight);

// Create models
const models = {
  can: createCan(),
  bottle: createBottle()
};

let currentModel = models.can;
scene.add(currentModel);

// Model creation functions
function createCan() {
  const geometry = new THREE.CylinderGeometry(1, 1, 2.5, 32);
  const material = new THREE.MeshPhongMaterial({ color: 0xff0000 });
  const can = new THREE.Mesh(geometry, material);
  
  // Add can details
  const topBottomGeo = new THREE.CylinderGeometry(1, 1, 0.1, 32);
  const topBottomMat = new THREE.MeshPhongMaterial({ color: 0x999999 });
  
  const top = new THREE.Mesh(topBottomGeo, topBottomMat);
  top.position.y = 1.3;
  can.add(top);
  
  const bottom = new THREE.Mesh(topBottomGeo, topBottomMat);
  bottom.position.y = -1.3;
  can.add(bottom);
  
  return can;
}

function createBottle() {
  const geometry = new THREE.CylinderGeometry(0.5, 1, 3, 32);
  const material = new THREE.MeshPhongMaterial({ 
    color: 0x00ff00,
    transparent: true,
    opacity: 0.7
  });
  const bottle = new THREE.Mesh(geometry, material);
  
  // Add bottle neck
  const neckGeo = new THREE.CylinderGeometry(0.3, 0.5, 0.5, 32);
  const neck = new THREE.Mesh(neckGeo, material);
  neck.position.y = 1.75;
  bottle.add(neck);
  
  return bottle;
}

// Handle window resize
function onWindowResize() {
  camera.aspect = canvas.clientWidth / canvas.clientHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(canvas.clientWidth, canvas.clientHeight, false);
}
window.addEventListener('resize', onWindowResize);

// Animation control
let rotate = true;

// Model switching
function switchModel(model) {
  scene.remove(currentModel);
  currentModel = model.clone();
  scene.add(currentModel);
}

// Event listeners
document.getElementById("cocaButton").addEventListener("click", () => {
  if (currentModel === models.can) {
    currentModel.material.color.set(0xff0000);
  }
});

document.getElementById("fantaButton").addEventListener("click", () => {
  if (currentModel === models.can) {
    currentModel.material.color.set(0xffa500);
  }
});

document.getElementById("spriteButton").addEventListener("click", () => {
  if (currentModel === models.can) {
    currentModel.material.color.set(0x00ff00);
  }
});

document.getElementById("bottleButton").addEventListener("click", () => {
  switchModel(models.bottle);
});

document.getElementById("canButton").addEventListener("click", () => {
  switchModel(models.can);
});

document.getElementById("wireframeButton").addEventListener("click", () => {
  currentModel.traverse((child) => {
    if (child.isMesh) {
      child.material.wireframe = !child.material.wireframe;
    }
  });
});

document.getElementById("lightButton").addEventListener("click", () => {
  directionalLight.visible = !directionalLight.visible;
});

document.getElementById("stopButton").addEventListener("click", () => {
  rotate = !rotate;
});

// Thumbnail click events
document.getElementById("cocaThumb").addEventListener("click", () => {
  switchModel(models.can);
  currentModel.material.color.set(0xff0000);
});

document.getElementById("fantaThumb").addEventListener("click", () => {
  switchModel(models.can);
  currentModel.material.color.set(0xffa500);
});

document.getElementById("spriteThumb").addEventListener("click", () => {
  switchModel(models.can);
  currentModel.material.color.set(0x00ff00);
});

// Animation loop
function animate() {
  requestAnimationFrame(animate);

  if (rotate) {
    currentModel.rotation.y += 0.01;
  }

  renderer.render(scene, camera);
}

// Initial setup
onWindowResize();
animate();